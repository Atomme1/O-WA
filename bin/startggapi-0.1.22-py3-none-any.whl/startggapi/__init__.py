from .__version__ import __author__, __title__, __version__
from .startggapi import StartGGAPI

__all__ = [
    "StartGGApi"
]
